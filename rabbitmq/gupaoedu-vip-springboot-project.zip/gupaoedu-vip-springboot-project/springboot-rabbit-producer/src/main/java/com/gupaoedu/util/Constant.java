package com.gupaoedu.util;

public class Constant {
	/**
	 * 定时任务状态
	 */
	public static class MERCHANT_STATE {
		/** 激活 */
		public static String ACITVE = "1";
		/** 关闭 */
		public static String CLOSE = "0";
	}

}
