package com.gupaoedu.consumer;

import com.gupaoedu.entity.Merchant;
import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.PropertySource;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * 第一个消费者 监听 firstQueue  ： 直连交换机
 * @Author: qingshan
 * @Date: 2018/10/20 17:04
 * @Description: 咕泡学院，只为更好的你
 * ${com.gupaoedu.firstqueue} GP_DIRECT_QUEUE_2
 */
@Component
@PropertySource("classpath:gupaomq.properties")
@RabbitListener(queues = "${com.gupaoedu.firstqueue}", containerFactory="rabbitListenerContainerFactory")
public class FirstConsumer {

    /*此代码为 原始工程代码
    @RabbitHandler
    public void process(@Payload Merchant merchant){
        System.out.println("First Queue received msg : " + merchant.getName());
    }*/

    @RabbitHandler
    public void process(@Payload Merchant merchant, Channel channel, Message message)throws IOException {
        System.out.println("First Queue Consumer received msg... : " + merchant.getName());
        channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);//确认消息 消费掉
    }

}
