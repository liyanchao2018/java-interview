package com.liyanchao.hystrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LycHystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
